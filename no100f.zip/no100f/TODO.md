# To Do
- Toggleable QOL Fixes  (Disable Aghast on a Mast Loading Zone when helmet isn't owned, remove Monster Gallery Snack Gate) 
- New Completion Goals
## Later
- Scooby Snack Randomization
