
## GCM functions from wwrando/wwlib

this is just the GCM functions from the [wwrando repo](https://github.com/LagoLunatic/wwrando)